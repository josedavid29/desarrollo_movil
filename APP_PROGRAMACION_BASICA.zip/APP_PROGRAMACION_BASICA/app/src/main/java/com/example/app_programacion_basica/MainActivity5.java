package com.example.app_programacion_basica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity5 extends AppCompatActivity {

    Button CAMBIO;
    Switch r11,r12,r13,r14;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        r11 = (Switch) findViewById(R.id.switch1);
        r12 = (Switch) findViewById(R.id.switch3);
        r13 = (Switch) findViewById(R.id.switch2);
        r14 = (Switch) findViewById(R.id.switch4);
        CAMBIO=(Button) findViewById(R.id.button4);
        CAMBIO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (r11.isChecked()) {
                    if (r12.isChecked()) {
                        if (r13.isChecked() ==false) {
                            if (r14.isChecked() == false) {
                                Toast.makeText(MainActivity5.this, "RESPUESTA CORRECTA", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(MainActivity5.this, MainActivity6.class);
                                startActivity(i);
                            }
                        }
                    }

                }
                if (r12.isChecked()==true||r14.isChecked()==true){
                    Toast.makeText(MainActivity5.this, "RESPUESTA INCORRECTA", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}