package com.example.app_programacion_basica;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity6 extends AppCompatActivity {

   Button salir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        salir = findViewById(R.id.button6);
    }
    @SuppressLint("")
    public void salir(View view){
        finishAffinity();
    }
}