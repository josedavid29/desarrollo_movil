package com.example.app_programacion_basica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {

    CheckBox cb1,cb2,cb3,cb4,cb5,cb6;
    Button CAMBIO;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        cb1 = (CheckBox) findViewById(R.id.checkBox);
        cb2 = (CheckBox) findViewById(R.id.checkBox2);
        cb3 = (CheckBox) findViewById(R.id.checkBox4);
        cb4 = (CheckBox) findViewById(R.id.checkBox5);
        cb5 = (CheckBox) findViewById(R.id.checkBox3);
        cb6 = (CheckBox) findViewById(R.id.checkBox6);
        CAMBIO=(Button) findViewById(R.id.button);
        CAMBIO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb1.isChecked() == true) {
                    if (cb2.isChecked() == true) {
                        if (cb3.isChecked() == false) {
                            if (cb4.isChecked() == true) {
                                if (cb5.isChecked() == false) {
                                    if (cb6.isChecked() == false) {
                                    Toast.makeText(MainActivity3.this, "RESPUESTA CORRECTA", Toast.LENGTH_SHORT).show();
                                    Intent i = new Intent(MainActivity3.this, MainActivity4.class);
                                    startActivity(i);
                                }
                            }
                        }
                    }
                    }
                }
                if (cb3.isChecked()==true||cb4.isChecked()==true||cb6.isChecked()==true){
                    Toast.makeText(MainActivity3.this, "RESPUESTA INCORRECTA", Toast.LENGTH_SHORT).show();
            }
            }
        });
    }
}